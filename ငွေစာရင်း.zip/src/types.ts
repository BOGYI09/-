export type ThemeColor = 'green' | 'blue' | 'purple' | 'orange';
export type ThemeMode = 'light' | 'dark' | 'system';
export type NumberFormatType = 'western' | 'myanmar';
export type Language = 'my' | 'en';

export interface Category {
  id: string;
  name: string; // e.g. ဆန်, ဆီဆား, ဆေးဝါး, ဘီယာသောက်, အစားအသောက်, ခရီး, အခြား
  icon: string; // lucide icon identifier
  color: string; // hex or tailwind class
  bgColor: string;
  isCustom?: boolean;
}

export interface Expense {
  id: string;
  title: string; // Name/description
  amount: number; // in Kyat
  categoryId: string;
  date: string; // YYYY-MM-DD
  note?: string;
  createdAt: number;
}

export interface MonthlyIncome {
  monthKey: string; // YYYY-MM, e.g. '2026-10'
  amount: number; // Base monthly income in Kyat
  notes?: string;
  updatedAt: number;
}

export interface IncomeEntry {
  id: string;
  title: string;
  amount: number;
  date: string; // YYYY-MM-DD
  monthKey: string; // YYYY-MM
  createdAt: number;
}

export interface CategorySummary {
  category: Category;
  totalAmount: number;
  percentage: number;
  count: number;
}
