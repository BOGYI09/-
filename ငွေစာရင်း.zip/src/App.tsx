import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BalanceCard } from './components/BalanceCard';
import { ExpenseList } from './components/ExpenseList';
import { AddExpenseModal } from './components/AddExpenseModal';
import { SetIncomeModal } from './components/SetIncomeModal';
import { MonthlyHistory } from './components/MonthlyHistory';
import { CategoriesView } from './components/CategoriesView';
import { SettingsModal } from './components/SettingsModal';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { BottomNav } from './components/BottomNav';
import { Expense } from './types';
import { Calendar, Tag, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';

function MainApp() {
  const { currentMonth, categorySummaries, themeColor, numberFormat, totalExpenses, t } = useApp();

  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'categories' | 'settings'>('home');
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [isIncomeModalOpen, setIsIncomeModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);

  const handleEditExpense = (expense: Expense) => {
    setEditingExpense(expense);
    setIsAddExpenseOpen(true);
  };

  const handleOpenAdd = () => {
    setEditingExpense(null);
    setIsAddExpenseOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100/80 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors pb-24 sm:pb-12">
      {/* Top Header */}
      <Header
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenIncomeModal={() => setIsIncomeModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-xl w-full mx-auto px-4 py-4 sm:py-6">
        {/* TAB 1: HOME (ပင်မ စာမျက်နှာ) */}
        {activeTab === 'home' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            {/* Financial Status Summary Card */}
            <BalanceCard
              onOpenIncomeModal={() => setIsIncomeModalOpen(true)}
              onOpenExpenseModal={handleOpenAdd}
            />

            {/* Quick Action Navigation Bar on Main Screen */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => setActiveTab('history')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/60 shadow-xs hover:shadow-md transition-all active:scale-98 text-left group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                      {t('home_quick_history_title')}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {t('home_quick_history_sub')}
                    </span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => setActiveTab('categories')}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/60 shadow-xs hover:shadow-md transition-all active:scale-98 text-left group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                    <Tag className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                      {t('home_quick_cat_title')}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {t('home_quick_cat_sub')}
                    </span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* All Expenses List */}
            <ExpenseList
              onAddExpense={handleOpenAdd}
              onEditExpense={handleEditExpense}
            />
          </div>
        )}

        {/* TAB 2: MONTHLY HISTORY (လစဉ် စာရင်း) */}
        {activeTab === 'history' && (
          <MonthlyHistory
            onEditExpense={handleEditExpense}
            onAddExpenseForMonth={() => handleOpenAdd()}
          />
        )}

        {/* TAB 3: CATEGORIES (အမျိုးအစားများ) */}
        {activeTab === 'categories' && (
          <CategoriesView
            onOpenAddCategory={() => setIsCategoryManagerOpen(true)}
          />
        )}

        {/* TAB 4: SETTINGS (ဆက်တင်များ) */}
        {activeTab === 'settings' && (
          <div className="space-y-4">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="w-full py-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-6 text-center shadow-xs"
            >
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                {t('settings_card_title')}
              </h3>
              <p className="text-xs text-slate-500">
                {t('settings_card_desc')}
              </p>
            </button>
          </div>
        )}
      </main>

      {/* Android Bottom Navigation & Floating Action Button */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'settings') {
            setIsSettingsOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenAddExpense={handleOpenAdd}
      />

      {/* Modals & Dialogs */}
      <AddExpenseModal
        isOpen={isAddExpenseOpen}
        onClose={() => {
          setIsAddExpenseOpen(false);
          setEditingExpense(null);
        }}
        editingExpense={editingExpense}
        onOpenCategoryManager={() => setIsCategoryManagerOpen(true)}
      />

      <SetIncomeModal
        isOpen={isIncomeModalOpen}
        onClose={() => setIsIncomeModalOpen(false)}
      />

      <CategoryManagerModal
        isOpen={isCategoryManagerOpen}
        onClose={() => setIsCategoryManagerOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
