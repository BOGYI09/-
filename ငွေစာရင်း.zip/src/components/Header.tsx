import React, { useState } from 'react';
import { Settings, Calendar, ChevronDown, Wallet, Search, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { THEME_CONFIGS, MYANMAR_MONTHS } from '../utils/constants';
import { formatShortMonthKey, getCurrentMonthKey } from '../utils/formatters';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenIncomeModal: () => void;
  activeTab: 'home' | 'history' | 'categories' | 'settings';
  setActiveTab: (tab: 'home' | 'history' | 'categories' | 'settings') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  activeTab,
  setActiveTab,
}) => {
  const {
    currentMonth,
    setCurrentMonth,
    allAvailableMonths,
    themeColor,
    numberFormat,
    searchQuery,
    setSearchQuery,
    language,
    t,
  } = useApp();

  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [showSearchBar, setShowSearchBar] = useState(false);

  const themeConfig = THEME_CONFIGS[themeColor];

  // Quick month change
  const handleSelectMonth = (monthKey: string) => {
    setCurrentMonth(monthKey);
    setShowMonthDropdown(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors shadow-xs">
      {/* Android-style Top Bar */}
      <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between gap-2">
        {/* Left: App Logo & Name */}
        <div className="flex items-center gap-2 shrink-0">
          <div
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr ${themeConfig.gradient} flex items-center justify-center text-white shadow-xs shrink-0`}
          >
            <Wallet className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <h1 className="text-[13px] sm:text-base font-bold tracking-tight text-slate-900 dark:text-white leading-tight whitespace-nowrap">
              {t('app_title')}
            </h1>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-none mt-0.5 whitespace-nowrap">
              {t('app_subtitle')}
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0 ml-auto">
          {/* Month selector chip button */}
          <div className="relative">
            <button
              onClick={() => setShowMonthDropdown(!showMonthDropdown)}
              className="flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200/60 dark:border-slate-700/60 transition-colors active:scale-95"
              title={t('select_month')}
            >
              <Calendar className="w-3 h-3 text-slate-500 dark:text-slate-400 shrink-0" />
              <span className="text-[11px] max-w-[85px] sm:max-w-none truncate">{formatShortMonthKey(currentMonth, numberFormat, language)}</span>
              <ChevronDown className="w-3 h-3 opacity-60 shrink-0" />
            </button>

            {/* Month Dropdown Modal/Popunder */}
            {showMonthDropdown && (
              <>
                <div
                  className="fixed inset-0 z-40 bg-black/20"
                  onClick={() => setShowMonthDropdown(false)}
                />
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {t('choose_month_modal')}
                    </span>
                    <button
                      onClick={() => handleSelectMonth(getCurrentMonthKey())}
                      className="text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
                    >
                      {t('this_month')}
                    </button>
                  </div>

                  <div className="max-h-60 overflow-y-auto p-1.5 space-y-1">
                    {allAvailableMonths.map((mKey) => {
                      const isSelected = mKey === currentMonth;
                      return (
                        <button
                          key={mKey}
                          onClick={() => handleSelectMonth(mKey)}
                          className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium transition-colors flex items-center justify-between ${
                            isSelected
                              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-semibold'
                              : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                          }`}
                        >
                          <span>{formatShortMonthKey(mKey, numberFormat, language)}</span>
                          {isSelected && (
                            <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="pt-2 px-2 border-t border-slate-100 dark:border-slate-700/60">
                    <button
                      onClick={() => {
                        setShowMonthDropdown(false);
                        setActiveTab('history');
                      }}
                      className="w-full text-center py-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors"
                    >
                      {t('view_full_history')} &rarr;
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Search Toggle button */}
          <button
            onClick={() => setShowSearchBar(!showSearchBar)}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
              showSearchBar || searchQuery
                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title={t('search_button')}
          >
            <Search className="w-3.5 h-3.5" />
          </button>

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            className="hidden sm:flex w-8 h-8 rounded-full items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={t('settings_button')}
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expandable Search Input Bar */}
      {showSearchBar && (
        <div className="max-w-xl mx-auto px-4 pb-3 pt-1 animate-in slide-in-from-top-2 duration-150">
          <div className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('search_placeholder')}
              className="w-full pl-9 pr-9 py-2 rounded-xl text-sm bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 border border-transparent focus:border-emerald-500 focus:bg-white dark:focus:bg-slate-900 outline-hidden transition-all"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
