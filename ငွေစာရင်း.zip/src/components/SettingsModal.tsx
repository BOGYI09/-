import React, { useRef, useState } from 'react';
import {
  X,
  Moon,
  Sun,
  Monitor,
  Palette,
  Check,
  Download,
  Upload,
  RotateCcw,
  Languages,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { THEME_CONFIGS } from '../utils/constants';
import { ThemeColor, Language } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    themeColor,
    setThemeColor,
    themeMode,
    setThemeMode,
    numberFormat,
    setNumberFormat,
    language,
    setLanguage,
    t,
    resetDataToDefault,
    exportDataJSON,
    importDataJSON,
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importSuccess, setImportSuccess] = useState<boolean | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  if (!isOpen) return null;

  const currentThemeConfig = THEME_CONFIGS[themeColor];

  const handleExport = () => {
    const jsonStr = exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ngwe-sar-yin-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDataJSON(content);
      setImportSuccess(success);
      setTimeout(() => setImportSuccess(null), 3000);
    };
    reader.readAsText(file);
  };

  const handleConfirmReset = () => {
    resetDataToDefault();
    setShowResetConfirm(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 z-10 max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div
              className={`p-2 rounded-2xl bg-gradient-to-tr ${currentThemeConfig.gradient} text-white`}
            >
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('settings_page_title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('settings_subtitle_label')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto space-y-5 pr-1">
          {/* Language Selection: English & Burmese */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Languages className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{t('language_section')}</span>
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLanguage('my')}
                className={`flex items-center justify-between p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  language === 'my'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 shadow-xs ring-1 ring-emerald-600'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-base">🇲🇲</span>
                  <div className="text-left">
                    <span className="block font-bold">မြန်မာ</span>
                    <span className="text-[10px] text-slate-400">Burmese</span>
                  </div>
                </div>
                {language === 'my' && (
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 stroke-[3]" />
                )}
              </button>

              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`flex items-center justify-between p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  language === 'en'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 shadow-xs ring-1 ring-emerald-600'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-base">🇬🇧</span>
                  <div className="text-left">
                    <span className="block font-bold">English</span>
                    <span className="text-[10px] text-slate-400">အင်္ဂလိပ်</span>
                  </div>
                </div>
                {language === 'en' && (
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 stroke-[3]" />
                )}
              </button>
            </div>
          </div>

          {/* Light / Dark Mode */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider block">
              {t('theme_mode_section')}
            </span>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setThemeMode('light')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  themeMode === 'light'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Sun className="w-4 h-4 mb-1 text-amber-500" />
                <span>{t('mode_light')}</span>
              </button>

              <button
                type="button"
                onClick={() => setThemeMode('dark')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  themeMode === 'dark'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Moon className="w-4 h-4 mb-1 text-indigo-400" />
                <span>{t('mode_dark')}</span>
              </button>

              <button
                type="button"
                onClick={() => setThemeMode('system')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold transition-all ${
                  themeMode === 'system'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Monitor className="w-4 h-4 mb-1 text-slate-500" />
                <span>{t('mode_system')}</span>
              </button>
            </div>
          </div>

          {/* Color Themes: Green, Blue, Purple, Orange */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider block">
              {t('color_theme_section')}
            </span>
            <div className="grid grid-cols-2 gap-2.5">
              {(Object.keys(THEME_CONFIGS) as ThemeColor[]).map((cKey) => {
                const conf = THEME_CONFIGS[cKey];
                const isSelected = themeColor === cKey;
                return (
                  <button
                    key={cKey}
                    type="button"
                    onClick={() => setThemeColor(cKey)}
                    className={`flex items-center gap-3 p-3 rounded-2xl border transition-all ${
                      isSelected
                        ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800 shadow-xs ring-1 ring-slate-900 dark:ring-white'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-white shrink-0 shadow-xs"
                      style={{ backgroundColor: conf.primary }}
                    >
                      {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {language === 'en' ? conf.name : conf.myanmarName}
                      </div>
                      <div className="text-[11px] text-slate-400 capitalize">
                        {language === 'en' ? (cKey === 'green' ? 'Default' : conf.name) : (cKey === 'green' ? '(မူလ)' : conf.name)}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Number Format Option */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider block">
              {t('number_format_section')}
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setNumberFormat('western')}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  numberFormat === 'western'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="text-sm font-semibold">1,000,000 Kyat</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{t('western_num_label')}</div>
              </button>

              <button
                type="button"
                onClick={() => setNumberFormat('myanmar')}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  numberFormat === 'myanmar'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="text-sm font-semibold">၁,၀၀၀,၀၀၀ ကျပ်</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{t('myanmar_num_label')}</div>
              </button>
            </div>
          </div>

          {/* Backup & Data Persistence Section */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider block">
              {t('backup_section')}
            </span>

            {importSuccess === true && (
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>{t('import_success_msg')}</span>
              </div>
            )}
            {importSuccess === false && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 text-xs font-semibold">
                {t('import_failed_msg')}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleExport}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t('export_backup_btn')}</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 active:scale-95"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{t('import_backup_btn')}</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </div>
          </div>

          {/* Reset App */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            {!showResetConfirm ? (
              <button
                type="button"
                onClick={() => setShowResetConfirm(true)}
                className="w-full py-2.5 rounded-2xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t('reset_data_btn')}</span>
              </button>
            ) : (
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 space-y-2">
                <p className="text-xs text-rose-700 dark:text-rose-300 font-semibold text-center">
                  {t('reset_confirm_msg')}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="py-1.5 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold"
                  >
                    {t('reset_confirm_no')}
                  </button>
                  <button
                    onClick={handleConfirmReset}
                    className="py-1.5 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700"
                  >
                    {t('reset_confirm_yes')}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* App Info Footer */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-center text-xs text-slate-400 space-y-0.5">
            <p className="font-semibold text-slate-600 dark:text-slate-400">{t('version_note')}</p>
            <p>{t('local_storage_note')}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
