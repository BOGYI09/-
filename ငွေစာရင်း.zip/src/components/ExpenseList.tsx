import React, { useState, useMemo } from 'react';
import {
  Plus,
  ShoppingBag,
  Trash2,
  Receipt,
} from 'lucide-react';
import { Expense } from '../types';
import { useApp } from '../context/AppContext';
import { ExpenseItem } from './ExpenseItem';
import { CategoryIcon } from './CategoryIcon';
import { formatAmount, formatDateDisplay } from '../utils/formatters';

interface ExpenseListProps {
  onAddExpense: () => void;
  onEditExpense: (expense: Expense) => void;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({
  onAddExpense,
  onEditExpense,
}) => {
  const {
    filteredExpenses,
    categories,
    selectedCategoryFilter,
    setSelectedCategoryFilter,
    deleteExpense,
    numberFormat,
    searchQuery,
    language,
    getCategoryName,
    t,
  } = useApp();

  const [deleteTarget, setDeleteTarget] = useState<Expense | null>(null);

  // Group filtered expenses by date
  const groupedExpenses = useMemo(() => {
    const groups: { [date: string]: { date: string; items: Expense[]; dayTotal: number } } = {};

    filteredExpenses.forEach((exp) => {
      if (!groups[exp.date]) {
        groups[exp.date] = { date: exp.date, items: [], dayTotal: 0 };
      }
      groups[exp.date].items.push(exp);
      groups[exp.date].dayTotal += exp.amount;
    });

    // Sort dates descending
    return Object.values(groups).sort((a, b) => b.date.localeCompare(a.date));
  }, [filteredExpenses]);

  const confirmDelete = () => {
    if (deleteTarget) {
      deleteExpense(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Category Filter Chips Carousel */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 px-0.5">
        <button
          onClick={() => setSelectedCategoryFilter(null)}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all active:scale-95 ${
            selectedCategoryFilter === null
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200/80 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          <span>{t('filter_all')}</span>
        </button>

        {categories.map((cat) => {
          const isSelected = selectedCategoryFilter === cat.id;
          const catName = getCategoryName(cat);
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategoryFilter(isSelected ? null : cat.id)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all active:scale-95 ${
                isSelected
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs font-semibold'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/80 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <CategoryIcon iconName={cat.icon} className="w-3.5 h-3.5" color={isSelected ? undefined : cat.color} />
              <span>{catName}</span>
            </button>
          );
        })}
      </div>

      {/* Expenses Header with Count */}
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
          <Receipt className="w-4 h-4 text-slate-500" />
          <span>{t('expenses_list_title')}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold">
            {formatAmount(filteredExpenses.length, numberFormat, false, language)} {t('items_unit')}
          </span>
        </h3>

        {selectedCategoryFilter && (
          <button
            onClick={() => setSelectedCategoryFilter(null)}
            className="text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 underline"
          >
            {t('clear_filter')}
          </button>
        )}
      </div>

      {/* Expenses List */}
      {groupedExpenses.length === 0 ? (
        /* Empty State */
        <div className="bg-white dark:bg-slate-800/80 rounded-3xl p-8 text-center border border-dashed border-slate-300 dark:border-slate-700">
          <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-700/50 flex items-center justify-center mx-auto mb-3 text-slate-400">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h4 className="text-base font-bold text-slate-800 dark:text-slate-200 mb-1">
            {searchQuery
              ? t('no_search_results')
              : t('no_expenses_title')}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto mb-4">
            {searchQuery
              ? t('try_other_search')
              : t('add_first_expense_prompt')}
          </p>
          <button
            onClick={onAddExpense}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{t('btn_add_expense')}</span>
          </button>
        </div>
      ) : (
        /* Grouped Expenses by Date */
        <div className="space-y-4">
          {groupedExpenses.map((group) => (
            <div key={group.date} className="space-y-2">
              {/* Date Header */}
              <div className="flex items-center justify-between px-1.5 pt-1">
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
                  {formatDateDisplay(group.date, numberFormat, language)}
                </span>
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {formatAmount(group.dayTotal, numberFormat, true, language)}
                </span>
              </div>

              {/* Expense Items in Date Group */}
              <div className="space-y-2">
                {group.items.map((exp) => (
                  <ExpenseItem
                    key={exp.id}
                    expense={exp}
                    onEdit={onEditExpense}
                    onDeleteRequest={(item) => setDeleteTarget(item)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-700 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-center text-slate-900 dark:text-white mb-1">
              {t('delete_confirm_title')}
            </h3>

            <p className="text-xs text-center text-slate-500 dark:text-slate-400 mb-4">
              "{deleteTarget.title}" ({formatAmount(deleteTarget.amount, numberFormat, true, language)}) {t('delete_confirm_suffix')}
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setDeleteTarget(null)}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 active:scale-95 transition-all"
              >
                {t('cancel_action')}
              </button>

              <button
                onClick={confirmDelete}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 active:scale-95 transition-all shadow-md shadow-rose-600/20"
              >
                {t('delete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
