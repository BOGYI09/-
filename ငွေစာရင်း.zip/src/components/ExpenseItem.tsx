import React, { useState } from 'react';
import { Trash2, Edit2, MoreVertical, FileText, Calendar } from 'lucide-react';
import { Expense } from '../types';
import { useApp } from '../context/AppContext';
import { CategoryIcon } from './CategoryIcon';
import { formatAmount, formatDateBurmese } from '../utils/formatters';

interface ExpenseItemProps {
  expense: Expense;
  onEdit: (expense: Expense) => void;
  onDeleteRequest: (expense: Expense) => void;
}

export const ExpenseItem: React.FC<ExpenseItemProps> = ({
  expense,
  onEdit,
  onDeleteRequest,
}) => {
  const { categories, numberFormat, language, getCategoryName, t } = useApp();
  const [showMenu, setShowMenu] = useState(false);

  const category = categories.find((c) => c.id === expense.categoryId) || {
    id: 'other',
    name: 'အခြား',
    icon: 'MoreHorizontal',
    color: '#64748b',
    bgColor: '#f1f5f9',
  };

  const categoryName = getCategoryName(category);

  return (
    <div className="relative group bg-white dark:bg-slate-800/90 rounded-2xl p-3.5 border border-slate-100 dark:border-slate-700/60 shadow-xs hover:shadow-md transition-all">
      <div className="flex items-center justify-between gap-3">
        {/* Left: Category Icon + Title & Note */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          {/* Icon Circle */}
          <div
            className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
            style={{
              backgroundColor: category.bgColor,
              color: category.color,
            }}
          >
            <CategoryIcon iconName={category.icon} className="w-5 h-5" color={category.color} />
          </div>

          {/* Details */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                {expense.title}
              </h4>
            </div>

            <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              {/* Category chip */}
              <span
                className="font-medium px-2 py-0.5 rounded-md text-[11px]"
                style={{
                  backgroundColor: category.bgColor,
                  color: category.color,
                }}
              >
                {categoryName}
              </span>

              {/* Note or date indicator */}
              {expense.note ? (
                <span className="truncate flex items-center gap-1 text-slate-400">
                  <FileText className="w-3 h-3 shrink-0" />
                  <span className="truncate">{expense.note}</span>
                </span>
              ) : (
                <span className="text-[11px] text-slate-400">
                  {formatDateBurmese(expense.date, numberFormat)}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Amount & Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="text-right">
            <span className="text-sm md:text-base font-bold text-rose-600 dark:text-rose-400">
              - {formatAmount(expense.amount, numberFormat, true, language)}
            </span>
          </div>

          {/* Action button */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              title={t('edit')}
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {/* Dropdown Menu */}
            {showMenu && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowMenu(false)}
                />
                <div className="absolute right-0 mt-1 w-36 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onEdit(expense);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t('edit')}</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onDeleteRequest(expense);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                    <span>{t('delete')}</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
