import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Wallet,
  PieChart,
  ListOrdered,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CategoryIcon } from './CategoryIcon';
import { ExpenseItem } from './ExpenseItem';
import { Expense } from '../types';
import { THEME_CONFIGS } from '../utils/constants';
import {
  formatAmount,
  formatMonthKey,
  formatShortMonthKey,
} from '../utils/formatters';

interface MonthlyHistoryProps {
  onEditExpense: (expense: Expense) => void;
  onAddExpenseForMonth: (monthKey: string) => void;
}

export const MonthlyHistory: React.FC<MonthlyHistoryProps> = ({
  onEditExpense,
}) => {
  const {
    currentMonth,
    getMonthStats,
    themeColor,
    numberFormat,
    deleteExpense,
    language,
    getCategoryName,
    t,
  } = useApp();

  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [selectedCatFilter, setSelectedCatFilter] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Expense | null>(null);

  const themeConfig = THEME_CONFIGS[themeColor];
  const stats = getMonthStats(selectedMonth);

  // Month navigation: previous month, next month
  const handlePrevMonth = () => {
    const [yearStr, monthStr] = selectedMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) - 1;
    if (month < 1) {
      month = 12;
      year -= 1;
    }
    const newMonthKey = `${year}-${String(month).padStart(2, '0')}`;
    setSelectedMonth(newMonthKey);
    setSelectedCatFilter(null);
  };

  const handleNextMonth = () => {
    const [yearStr, monthStr] = selectedMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) + 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
    const newMonthKey = `${year}-${String(month).padStart(2, '0')}`;
    setSelectedMonth(newMonthKey);
    setSelectedCatFilter(null);
  };

  // Filter expenses by category if clicked in summary
  const displayedExpenses = selectedCatFilter
    ? stats.expenses.filter((e) => e.categoryId === selectedCatFilter)
    : stats.expenses;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Month Selection Bar */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-2">
        <button
          onClick={handlePrevMonth}
          className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 transition-colors active:scale-95"
          title="Previous Month"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        {/* Month Dropdown / Title */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 font-semibold uppercase tracking-wider mb-0.5">
            <Calendar className="w-3 h-3" />
            <span>{t('history_page_title')}</span>
          </div>
          <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
            {formatMonthKey(selectedMonth, numberFormat, language)}
          </h2>
        </div>

        <button
          onClick={handleNextMonth}
          className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 transition-colors active:scale-95"
          title="Next Month"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Month Financial Overview Cards */}
      <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
        {/* Income Card */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-700/60 shadow-xs">
          <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold mb-1">
            <TrendingUp className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{t('total_income')}</span>
          </div>
          <div className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
            {formatAmount(stats.totalIncome, numberFormat, true, language)}
          </div>
        </div>

        {/* Expenses Card */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-700/60 shadow-xs">
          <div className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 font-semibold mb-1">
            <TrendingDown className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{t('total_expenses')}</span>
          </div>
          <div className="text-sm sm:text-base font-bold text-rose-600 dark:text-rose-400 truncate">
            {formatAmount(stats.totalExpenses, numberFormat, true, language)}
          </div>
        </div>

        {/* Balance Card */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-700/60 shadow-xs">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-semibold mb-1">
            <Wallet className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{t('remaining_balance')}</span>
          </div>
          <div
            className={`text-sm sm:text-base font-bold truncate ${
              stats.remainingBalance < 0
                ? 'text-rose-600 dark:text-rose-400'
                : 'text-slate-900 dark:text-white'
            }`}
          >
            {formatAmount(stats.remainingBalance, numberFormat, true, language)}
          </div>
        </div>
      </div>

      {/* Category-wise Summary Section (Exactly as requested) */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/60 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
          <div className="flex items-center gap-2">
            <div
              className={`p-1.5 rounded-xl bg-gradient-to-tr ${themeConfig.gradient} text-white`}
            >
              <PieChart className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t('category_summary_title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('category_summary_total')} <span className="font-bold text-slate-800 dark:text-slate-200">{formatAmount(stats.totalExpenses, numberFormat, true, language)}</span>
              </p>
            </div>
          </div>

          {selectedCatFilter && (
            <button
              onClick={() => setSelectedCatFilter(null)}
              className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              {t('show_all')}
            </button>
          )}
        </div>

        {stats.categorySummaries.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400">
            {t('no_records_this_month')}
          </div>
        ) : (
          <div className="space-y-3">
            {stats.categorySummaries.map((item) => {
              const isSelected = selectedCatFilter === item.category.id;
              const catName = getCategoryName(item.category);
              return (
                <div
                  key={item.category.id}
                  onClick={() =>
                    setSelectedCatFilter(isSelected ? null : item.category.id)
                  }
                  className={`p-3 rounded-2xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-100 dark:bg-slate-700/70 ring-1 ring-emerald-500'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-750'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                        style={{
                          backgroundColor: item.category.bgColor,
                          color: item.category.color,
                        }}
                      >
                        <CategoryIcon iconName={item.category.icon} className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-slate-900 dark:text-white">
                          - {catName}:
                        </span>
                        <span className="text-xs text-slate-400 ml-1.5">
                          ({formatAmount(item.count, numberFormat, false, language)} {t('times_unit')})
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {formatAmount(item.totalAmount, numberFormat, true, language)}
                      </span>
                      <span className="text-[11px] text-slate-400 ml-1.5 font-medium">
                        ({Math.round(item.percentage)}%)
                      </span>
                    </div>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${Math.min(100, Math.max(2, item.percentage))}%`,
                        backgroundColor: item.category.color,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Full List of Expenses for Month */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <ListOrdered className="w-4 h-4 text-slate-500" />
            <span>
              {formatShortMonthKey(selectedMonth, numberFormat, language)} {t('expenses_for_month_prefix')}
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold">
              {formatAmount(displayedExpenses.length, numberFormat, false, language)} {t('items_unit')}
            </span>
          </h3>
        </div>

        {displayedExpenses.length === 0 ? (
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-700">
            {t('no_records_this_month')}
          </div>
        ) : (
          <div className="space-y-2">
            {displayedExpenses.map((exp) => (
              <ExpenseItem
                key={exp.id}
                expense={exp}
                onEdit={onEditExpense}
                onDeleteRequest={(item) => setDeleteTarget(item)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-700 animate-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 text-center">
              {t('delete_confirm_title')}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 text-center">
              "{deleteTarget.title}" ({formatAmount(deleteTarget.amount, numberFormat, true, language)}) {t('delete_confirm_suffix')}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setDeleteTarget(null)}
                className="py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
              >
                {t('cancel_action')}
              </button>
              <button
                onClick={() => {
                  deleteExpense(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="py-2.5 rounded-xl text-xs font-semibold bg-rose-600 text-white"
              >
                {t('delete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
