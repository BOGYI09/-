import React, { useState, useEffect } from 'react';
import { X, Check, Wallet, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { THEME_CONFIGS } from '../utils/constants';
import { formatAmount, formatShortMonthKey } from '../utils/formatters';

interface SetIncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SetIncomeModal: React.FC<SetIncomeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { currentMonth, totalIncome, setMonthIncome, themeColor, numberFormat, language, t } = useApp();
  const themeConfig = THEME_CONFIGS[themeColor];

  const [amountStr, setAmountStr] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  const presets = [500000, 800000, 1000000, 1500000, 2000000, 3000000];

  useEffect(() => {
    if (isOpen) {
      setAmountStr(String(totalIncome || 1000000));
      setNotes(t('income_default_note'));
      setError(null);
    }
  }, [isOpen, totalIncome, language]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAmount = parseFloat(amountStr);
    if (isNaN(cleanAmount) || cleanAmount < 0) {
      setError(t('err_income_invalid'));
      return;
    }

    setMonthIncome(currentMonth, cleanAmount, notes.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 z-10 animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-2xl bg-gradient-to-tr ${themeConfig.gradient} flex items-center justify-center text-white`}
            >
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('income_modal_title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('income_modal_for')} {formatShortMonthKey(currentMonth, numberFormat, language)}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('income_amount_label')}
            </label>
            <div className="relative">
              <input
                type="number"
                inputMode="numeric"
                step="any"
                min="0"
                value={amountStr}
                onChange={(e) => {
                  setAmountStr(e.target.value);
                  setError(null);
                }}
                placeholder="1000000"
                className="w-full text-2xl font-bold px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 text-center"
                autoFocus
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                {language === 'en' ? 'Kyat' : 'ကျပ်'}
              </span>
            </div>

            {/* Presets */}
            <div className="mt-3">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5 text-center">
                {t('income_presets_label')}
              </span>
              <div className="grid grid-cols-3 gap-2">
                {presets.map((p) => (
                  <button
                    type="button"
                    key={p}
                    onClick={() => setAmountStr(String(p))}
                    className="py-1.5 px-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors active:scale-95 text-center"
                  >
                    {formatAmount(p, numberFormat, true, language)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('income_note_label')}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Monthly Salary"
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className={`w-full py-3 rounded-2xl font-bold text-sm text-white shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2 ${themeConfig.primaryClass}`}
            >
              <Check className="w-4 h-4" />
              <span>{t('btn_set_income')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
