import React, { useState } from 'react';
import { X, Plus, Trash2, Check, Tag, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CategoryIcon, AVAILABLE_CATEGORY_ICONS } from './CategoryIcon';
import { THEME_CONFIGS } from '../utils/constants';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_COLORS = [
  { color: '#059669', bgColor: '#d1fae5', name: 'Emerald' },
  { color: '#2563eb', bgColor: '#dbeafe', name: 'Blue' },
  { color: '#8b5cf6', bgColor: '#ede9fe', name: 'Purple' },
  { color: '#ea580c', bgColor: '#ffedd5', name: 'Orange' },
  { color: '#e11d48', bgColor: '#ffe4e6', name: 'Rose' },
  { color: '#d97706', bgColor: '#fef3c7', name: 'Amber' },
  { color: '#0891b2', bgColor: '#cffafe', name: 'Cyan' },
  { color: '#4f46e5', bgColor: '#e0e7ff', name: 'Indigo' },
  { color: '#64748b', bgColor: '#f1f5f9', name: 'Slate' },
];

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { categories, addCategory, deleteCategory, themeColor, getCategoryName, t } = useApp();
  const themeConfig = THEME_CONFIGS[themeColor];

  const [name, setName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState(AVAILABLE_CATEGORY_ICONS[0].name);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError(t('err_cat_name_empty'));
      return;
    }

    // Check duplicate
    if (categories.some((c) => c.name.toLowerCase() === cleanName.toLowerCase())) {
      setError(t('err_cat_duplicate'));
      return;
    }

    const colorConfig = PRESET_COLORS[selectedColorIndex];
    addCategory({
      name: cleanName,
      icon: selectedIcon,
      color: colorConfig.color,
      bgColor: colorConfig.bgColor,
    });

    setName('');
    setIsAdding(false);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 z-10 max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div
              className={`p-1.5 rounded-xl bg-gradient-to-tr ${themeConfig.gradient} text-white`}
            >
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('categories_page_title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('existing_categories_label')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto space-y-4 pr-1">
          {/* New Category Form Toggle or Form */}
          {!isAdding ? (
            <button
              onClick={() => setIsAdding(true)}
              className="w-full py-2.5 px-4 rounded-2xl border-2 border-dashed border-emerald-500/50 hover:border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>{t('create_category_card')}</span>
            </button>
          ) : (
            <form
              onSubmit={handleCreate}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {t('create_category_title')}
                </span>
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  {t('close_btn')}
                </button>
              </div>

              {error && (
                <div className="flex items-center gap-1.5 p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 text-xs font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  {t('cat_name_input_label')}
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setError(null);
                  }}
                  placeholder={t('cat_name_placeholder')}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              {/* Icon Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  {t('choose_icon_label')}
                </label>
                <div className="grid grid-cols-6 gap-1.5 max-h-32 overflow-y-auto p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                  {AVAILABLE_CATEGORY_ICONS.map((item) => {
                    const isSelected = selectedIcon === item.name;
                    return (
                      <button
                        type="button"
                        key={item.name}
                        onClick={() => setSelectedIcon(item.name)}
                        className={`p-2 rounded-xl flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                        }`}
                        title={item.label}
                      >
                        <CategoryIcon iconName={item.name} className="w-4 h-4" />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Color Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  {t('choose_color_label')}
                </label>
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map((c, idx) => (
                    <button
                      type="button"
                      key={c.color}
                      onClick={() => setSelectedColorIndex(idx)}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform ${
                        selectedColorIndex === idx ? 'scale-110 ring-2 ring-slate-900 dark:ring-white' : ''
                      }`}
                      style={{ backgroundColor: c.color }}
                    >
                      {selectedColorIndex === idx && (
                        <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className={`w-full py-2.5 rounded-xl font-bold text-xs text-white shadow-md transition-all ${themeConfig.primaryClass}`}
              >
                {t('btn_save')}
              </button>
            </form>
          )}

          {/* List of existing categories */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              {t('existing_categories_label')} ({categories.length})
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {categories.map((cat) => {
                const catName = getCategoryName(cat);
                return (
                  <div
                    key={cat.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                        style={{ backgroundColor: cat.bgColor, color: cat.color }}
                      >
                        <CategoryIcon iconName={cat.icon} className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                        {catName}
                      </span>
                    </div>

                    {cat.isCustom && (
                      <button
                        onClick={() => deleteCategory(cat.id)}
                        className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                        title={t('delete')}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
