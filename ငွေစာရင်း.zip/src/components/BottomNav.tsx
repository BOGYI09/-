import React from 'react';
import { Home, Calendar, Tag, Settings, Plus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { THEME_CONFIGS } from '../utils/constants';

interface BottomNavProps {
  activeTab: 'home' | 'history' | 'categories' | 'settings';
  setActiveTab: (tab: 'home' | 'history' | 'categories' | 'settings') => void;
  onOpenAddExpense: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddExpense,
}) => {
  const { themeColor, t } = useApp();
  const themeConfig = THEME_CONFIGS[themeColor];

  const navItems = [
    {
      id: 'home' as const,
      label: t('nav_home'),
      icon: Home,
    },
    {
      id: 'history' as const,
      label: t('nav_history'),
      icon: Calendar,
    },
    {
      id: 'categories' as const,
      label: t('nav_categories'),
      icon: Tag,
    },
    {
      id: 'settings' as const,
      label: t('nav_settings'),
      icon: Settings,
    },
  ];

  return (
    <>
      {/* Floating Action Button (Android Material FAB) */}
      <div className="fixed right-5 bottom-20 sm:bottom-6 sm:right-8 z-30 pointer-events-auto">
        <button
          onClick={onOpenAddExpense}
          className={`flex items-center gap-2 pl-4 pr-5 py-3.5 rounded-full text-white shadow-xl shadow-slate-900/20 active:scale-95 transition-all transform hover:-translate-y-0.5 ${themeConfig.primaryClass}`}
          title={t('btn_add_expense')}
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
          <span className="text-sm font-bold tracking-wide">{t('nav_add')}</span>
        </button>
      </div>

      {/* Android Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 pb-safe">
        <div className="max-w-xl mx-auto px-4 h-16 flex items-center justify-around">
          {navItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all relative ${
                  isActive
                    ? 'text-slate-900 dark:text-white font-bold'
                    : 'text-slate-600 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                {/* Active Indicator background pill */}
                <div
                  className={`px-4 py-1 rounded-full transition-colors flex items-center justify-center ${
                    isActive
                      ? themeConfig.badgeClass
                      : 'bg-transparent'
                  }`}
                >
                  <IconComponent
                    className={`w-5 h-5 transition-transform ${
                      isActive ? 'scale-110' : ''
                    }`}
                  />
                </div>
                <span className="text-[11px] mt-0.5 tracking-tight truncate">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
