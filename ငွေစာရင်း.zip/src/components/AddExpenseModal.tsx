import React, { useState, useEffect } from 'react';
import { X, Check, Calendar, Plus, Tag, FileText, AlertCircle } from 'lucide-react';
import { Expense } from '../types';
import { useApp } from '../context/AppContext';
import { CategoryIcon } from './CategoryIcon';
import { THEME_CONFIGS } from '../utils/constants';
import { getTodayDateString, formatAmount } from '../utils/formatters';

interface AddExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingExpense?: Expense | null;
  onOpenCategoryManager: () => void;
}

export const AddExpenseModal: React.FC<AddExpenseModalProps> = ({
  isOpen,
  onClose,
  editingExpense,
  onOpenCategoryManager,
}) => {
  const {
    categories,
    addExpense,
    updateExpense,
    themeColor,
    numberFormat,
    language,
    getCategoryName,
    t,
  } = useApp();
  const themeConfig = THEME_CONFIGS[themeColor];

  const [title, setTitle] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Quick amount additions
  const quickAmounts = [1000, 5000, 10000, 50000, 100000];

  useEffect(() => {
    if (editingExpense) {
      setTitle(editingExpense.title);
      setAmountStr(String(editingExpense.amount));
      setSelectedCategoryId(editingExpense.categoryId);
      setDate(editingExpense.date);
      setNote(editingExpense.note || '');
      setError(null);
    } else {
      // Default reset
      setTitle('');
      setAmountStr('');
      setSelectedCategoryId(categories.length > 0 ? categories[0].id : '');
      setDate(getTodayDateString());
      setNote('');
      setError(null);
    }
  }, [editingExpense, isOpen, categories]);

  if (!isOpen) return null;

  const handleQuickAdd = (increment: number) => {
    const current = parseFloat(amountStr) || 0;
    setAmountStr(String(current + increment));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTitle = title.trim();
    const cleanAmount = parseFloat(amountStr);

    if (!cleanTitle) {
      setError(t('err_title_required'));
      return;
    }

    if (isNaN(cleanAmount) || cleanAmount <= 0) {
      setError(t('err_amount_invalid'));
      return;
    }

    if (!selectedCategoryId) {
      setError(t('err_category_required'));
      return;
    }

    if (!date) {
      setError(t('err_date_required'));
      return;
    }

    if (editingExpense) {
      updateExpense(editingExpense.id, {
        title: cleanTitle,
        amount: cleanAmount,
        categoryId: selectedCategoryId,
        date,
        note: note.trim() || undefined,
      });
    } else {
      addExpense({
        title: cleanTitle,
        amount: cleanAmount,
        categoryId: selectedCategoryId,
        date,
        note: note.trim() || undefined,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Backdrop */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal / Bottom Sheet */}
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 z-10 max-h-[92vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom sm:zoom-in-95 duration-200">
        {/* Android drag bar indicator on mobile */}
        <div className="sm:hidden w-12 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700 mx-auto mt-3" />

        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingExpense ? t('modal_edit_title') : t('modal_add_title')}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t('modal_subtitle')}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Amount Input Hero */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('amount_label')} <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="number"
                inputMode="numeric"
                step="any"
                min="1"
                value={amountStr}
                onChange={(e) => {
                  setAmountStr(e.target.value);
                  setError(null);
                }}
                placeholder={t('amount_placeholder')}
                className="w-full text-2xl font-bold px-4 py-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 transition-all text-center"
                autoFocus={!editingExpense}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500 dark:text-slate-400">
                {language === 'en' ? 'Kyat' : 'ကျပ်'}
              </span>
            </div>

            {/* Quick add amount badges */}
            <div className="flex flex-wrap gap-1.5 mt-2 justify-center">
              {quickAmounts.map((q) => (
                <button
                  type="button"
                  key={q}
                  onClick={() => handleQuickAdd(q)}
                  className="px-2.5 py-1 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors active:scale-95"
                >
                  +{formatAmount(q, numberFormat, false, language)}
                </button>
              ))}
            </div>
          </div>

          {/* Description / Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('name_label')} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setError(null);
              }}
              placeholder={t('name_placeholder')}
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 text-sm transition-all"
            />
          </div>

          {/* Category Selection Grid */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5" />
                <span>{t('category_label')}</span> <span className="text-rose-500">*</span>
              </label>
              <button
                type="button"
                onClick={onOpenCategoryManager}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>{t('add_new_category')}</span>
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {categories.map((cat) => {
                const isSelected = selectedCategoryId === cat.id;
                const catName = getCategoryName(cat);
                return (
                  <button
                    type="button"
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategoryId(cat.id);
                      setError(null);
                    }}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border text-center transition-all active:scale-95 ${
                      isSelected
                        ? 'border-slate-900 dark:border-white bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md'
                        : 'border-slate-200/80 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center mb-1.5 shadow-xs"
                      style={{
                        backgroundColor: isSelected ? 'rgba(255,255,255,0.2)' : cat.bgColor,
                        color: isSelected ? 'inherit' : cat.color,
                      }}
                    >
                      <CategoryIcon iconName={cat.icon} className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-medium truncate w-full">
                      {catName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>{t('date_label')}</span>
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Optional Note */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" />
              <span>{t('note_label')}</span>
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t('note_placeholder')}
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 text-sm"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              className={`w-full py-3.5 rounded-2xl font-bold text-sm text-white shadow-lg shadow-emerald-900/10 active:scale-[0.98] transition-all flex items-center justify-center gap-2 ${themeConfig.primaryClass}`}
            >
              <Check className="w-4 h-4" />
              <span>{editingExpense ? t('btn_save') : t('btn_submit_expense')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
