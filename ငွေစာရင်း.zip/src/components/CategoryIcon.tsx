import React from 'react';
import {
  Wheat,
  ShoppingBag,
  HeartPulse,
  Beer,
  UtensilsCrossed,
  Navigation,
  MoreHorizontal,
  Coffee,
  Car,
  Home,
  Zap,
  Shirt,
  BookOpen,
  Phone,
  Gift,
  Music,
  Tv,
  Gamepad2,
  Smile,
  LucideIcon,
} from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  Wheat,
  ShoppingBag,
  HeartPulse,
  Beer,
  UtensilsCrossed,
  Navigation,
  MoreHorizontal,
  Coffee,
  Car,
  Home,
  Zap,
  Shirt,
  BookOpen,
  Phone,
  Gift,
  Music,
  Tv,
  Gamepad2,
  Smile,
};

interface CategoryIconProps {
  iconName: string;
  className?: string;
  color?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({
  iconName,
  className = 'w-5 h-5',
  color,
}) => {
  const IconComponent = ICON_MAP[iconName] || MoreHorizontal;
  return <IconComponent className={className} style={color ? { color } : undefined} />;
};

export const AVAILABLE_CATEGORY_ICONS = [
  { name: 'Wheat', label: 'ဆန်/သီးနှံ' },
  { name: 'ShoppingBag', label: 'ဈေးဝယ်' },
  { name: 'HeartPulse', label: 'ဆေးဝါး/ကျန်းမာရေး' },
  { name: 'Beer', label: 'ဘီယာ/ဖျော်ရည်' },
  { name: 'UtensilsCrossed', label: 'အစားအသောက်' },
  { name: 'Navigation', label: 'ခရီးစရိတ်' },
  { name: 'Car', label: 'ယာဉ်/ကားခ' },
  { name: 'Coffee', label: 'လက်ဖက်ရည်/ကော်ဖီ' },
  { name: 'Home', label: 'အိမ်စရိတ်' },
  { name: 'Zap', label: 'မီတာခ/လျှပ်စစ်' },
  { name: 'Phone', label: 'ဖုန်းဘေလ်' },
  { name: 'Shirt', label: 'အဝတ်အထည်' },
  { name: 'BookOpen', label: 'ပညာရေး' },
  { name: 'Gift', label: 'လက်ဆောင်' },
  { name: 'Music', label: 'ဖျော်ဖြေရေး' },
  { name: 'Tv', label: 'တီဗွီ/အင်တာနက်' },
  { name: 'Gamepad2', label: 'ဂိမ်း' },
  { name: 'Smile', label: 'အထွေထွေ' },
  { name: 'MoreHorizontal', label: 'အခြား' },
];
