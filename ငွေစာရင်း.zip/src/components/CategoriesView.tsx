import React, { useState } from 'react';
import { Plus, Tag, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CategoryIcon } from './CategoryIcon';
import { THEME_CONFIGS } from '../utils/constants';
import { formatAmount } from '../utils/formatters';

interface CategoriesViewProps {
  onOpenAddCategory: () => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  onOpenAddCategory,
}) => {
  const {
    categories,
    categorySummaries,
    deleteCategory,
    themeColor,
    numberFormat,
    totalExpenses,
    language,
    getCategoryName,
    t,
  } = useApp();
  const themeConfig = THEME_CONFIGS[themeColor];
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Map summaries to categories
  const summaryMap = new Map(categorySummaries.map((s) => [s.category.id, s]));

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Tag className="w-5 h-5 text-emerald-600" />
            <span>{t('categories_page_title')}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {t('categories_total_prefix')} {categories.length} {t('categories_total_suffix')}
          </p>
        </div>

        <button
          onClick={onOpenAddCategory}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold text-white shadow-md active:scale-95 transition-all ${themeConfig.primaryClass}`}
        >
          <Plus className="w-4 h-4" />
          <span>{t('btn_add_category')}</span>
        </button>
      </div>

      {/* Grid of categories with stats for current month */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {categories.map((cat) => {
          const stats = summaryMap.get(cat.id);
          const spentThisMonth = stats ? stats.totalAmount : 0;
          const countThisMonth = stats ? stats.count : 0;
          const percent = totalExpenses > 0 && spentThisMonth > 0 ? (spentThisMonth / totalExpenses) * 100 : 0;
          const catName = getCategoryName(cat);

          return (
            <div
              key={cat.id}
              className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-700/60 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                    style={{ backgroundColor: cat.bgColor, color: cat.color }}
                  >
                    <CategoryIcon iconName={cat.icon} className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>{catName}</span>
                      {cat.isCustom && (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                          {t('custom_tag')}
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {countThisMonth > 0 ? `${formatAmount(countThisMonth, numberFormat, false, language)} ${t('times_unit')}` : t('no_spending_yet')}
                    </p>
                  </div>
                </div>

                {cat.isCustom && (
                  <button
                    onClick={() => setDeleteTargetId(cat.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors"
                    title={t('delete')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Amount & Bar */}
              <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-750">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">
                    {t('monthly_spending_label')}
                  </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {formatAmount(spentThisMonth, numberFormat, true, language)}
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, Math.max(spentThisMonth > 0 ? 3 : 0, percent))}%`,
                      backgroundColor: cat.color,
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Delete Confirmation Modal for Custom Category */}
      {deleteTargetId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-700">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 text-center">
              {t('delete_category_confirm')}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 text-center">
              {t('delete_category_desc')}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setDeleteTargetId(null)}
                className="py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
              >
                {t('cancel_action')}
              </button>
              <button
                onClick={() => {
                  deleteCategory(deleteTargetId);
                  setDeleteTargetId(null);
                }}
                className="py-2.5 rounded-xl text-xs font-semibold bg-rose-600 text-white"
              >
                {t('delete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
