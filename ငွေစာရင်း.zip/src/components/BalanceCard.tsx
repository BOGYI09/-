import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Edit3,
  AlertCircle,
  PlusCircle,
  Calendar,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { THEME_CONFIGS } from '../utils/constants';
import { formatAmount, formatShortMonthKey } from '../utils/formatters';

interface BalanceCardProps {
  onOpenIncomeModal: () => void;
  onOpenExpenseModal: () => void;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({
  onOpenIncomeModal,
  onOpenExpenseModal,
}) => {
  const {
    totalIncome,
    totalExpenses,
    remainingBalance,
    themeColor,
    numberFormat,
    currentMonth,
    language,
    t,
  } = useApp();

  const themeConfig = THEME_CONFIGS[themeColor];

  // Calculate percentage used
  const percentSpent =
    totalIncome > 0
      ? Math.min(100, Math.round((totalExpenses / totalIncome) * 100))
      : totalExpenses > 0
      ? 100
      : 0;

  const isOverBudget = remainingBalance < 0;

  return (
    <div className="w-full">
      {/* Material 3 Card Container */}
      <div
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${themeConfig.gradient} text-white shadow-xl shadow-slate-900/10 p-5 md:p-6 transition-all`}
      >
        {/* Decorative background blurs */}
        <div className="absolute -top-12 -right-12 w-44 h-44 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-44 h-44 rounded-full bg-black/10 blur-2xl pointer-events-none" />

        {/* Top row: Label & Month Badge */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md">
            <Calendar className="w-3 h-3 text-white/80" />
            <span className="text-[11px] font-medium tracking-normal text-white">
              {formatShortMonthKey(currentMonth, numberFormat, language)}
            </span>
          </div>

          <button
            onClick={onOpenIncomeModal}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-white/20 hover:bg-white/30 backdrop-blur-md text-white transition-all active:scale-95"
            title={t('edit_income')}
          >
            <Edit3 className="w-3 h-3" />
            <span>{t('edit_income')}</span>
          </button>
        </div>

        {/* Main highlight: Remaining Balance */}
        <div className="mt-2 mb-4">
          <div className="text-xs font-medium text-white/80">{t('remaining_balance')}</div>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span
              className={`text-3xl md:text-4xl font-extrabold tracking-tight ${
                isOverBudget ? 'text-rose-200' : 'text-white'
              }`}
            >
              {formatAmount(remainingBalance, numberFormat, true, language)}
            </span>
          </div>
          {isOverBudget && (
            <div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-rose-200 bg-rose-950/40 px-2.5 py-1 rounded-lg w-fit">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{t('over_budget_warning')}</span>
            </div>
          )}
        </div>

        {/* Two-column summary: Total Income & Total Expenses */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/20">
          {/* Income Column */}
          <div
            onClick={onOpenIncomeModal}
            className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-3 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-1.5 text-xs text-white/80 mb-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-200" />
              <span>{t('total_income')}</span>
            </div>
            <div className="text-base md:text-lg font-bold text-white truncate">
              {formatAmount(totalIncome, numberFormat, true, language)}
            </div>
          </div>

          {/* Expenses Column */}
          <div
            onClick={onOpenExpenseModal}
            className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-3 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-1.5 text-xs text-white/80 mb-1">
              <TrendingDown className="w-3.5 h-3.5 text-rose-200" />
              <span>{t('total_expenses')}</span>
            </div>
            <div className="text-base md:text-lg font-bold text-white truncate">
              {formatAmount(totalExpenses, numberFormat, true, language)}
            </div>
          </div>
        </div>

        {/* Progress bar of budget used */}
        <div className="mt-4 pt-1">
          <div className="flex justify-between items-center text-xs text-white/85 mb-1.5">
            <span>{t('spending_percentage')}</span>
            <span className="font-semibold">
              {numberFormat === 'myanmar'
                ? formatAmount(percentSpent, numberFormat, false, language)
                : `${percentSpent}`}%
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-white/20 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                percentSpent > 90
                  ? 'bg-rose-400'
                  : percentSpent > 70
                  ? 'bg-amber-300'
                  : 'bg-white'
              }`}
              style={{ width: `${Math.min(100, Math.max(0, percentSpent))}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
