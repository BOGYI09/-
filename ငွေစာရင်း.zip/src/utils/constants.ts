import { Category, ThemeColor } from '../types';

export const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'rice',
    name: 'ဆန်',
    icon: 'Wheat',
    color: '#d97706', // amber-600
    bgColor: '#fef3c7', // amber-100
  },
  {
    id: 'groceries',
    name: 'ဆီဆား',
    icon: 'ShoppingBag',
    color: '#059669', // emerald-600
    bgColor: '#d1fae5', // emerald-100
  },
  {
    id: 'medicine',
    name: 'ဆေးဝါး',
    icon: 'HeartPulse',
    color: '#e11d48', // rose-600
    bgColor: '#ffe4e6', // rose-100
  },
  {
    id: 'beer',
    name: 'ဘီယာသောက်',
    icon: 'Beer',
    color: '#b45309', // amber-700
    bgColor: '#fef3c7', // amber-100
  },
  {
    id: 'food',
    name: 'အစားအသောက်',
    icon: 'UtensilsCrossed',
    color: '#ea580c', // orange-600
    bgColor: '#ffedd5', // orange-100
  },
  {
    id: 'travel',
    name: 'ခရီး',
    icon: 'Navigation',
    color: '#2563eb', // blue-600
    bgColor: '#dbeafe', // blue-100
  },
  {
    id: 'other',
    name: 'အခြား',
    icon: 'MoreHorizontal',
    color: '#64748b', // slate-500
    bgColor: '#f1f5f9', // slate-100
  },
];

export const MYANMAR_MONTHS = [
  { value: '01', name: 'ဇန်နဝါရီ', short: 'ဇန်' },
  { value: '02', name: 'ဖေဖော်ဝါရီ', short: 'ဖေ' },
  { value: '03', name: 'မတ်', short: 'မတ်' },
  { value: '04', name: 'ဧပြီ', short: 'ဧပြီ' },
  { value: '05', name: 'မေ', short: 'မေ' },
  { value: '06', name: 'ဇွန်', short: 'ဇွန်' },
  { value: '07', name: 'ဇူလိုင်', short: 'ဇူ' },
  { value: '08', name: 'သြဂုတ်', short: 'သြ' },
  { value: '09', name: 'စက်တင်ဘာ', short: 'စက်' },
  { value: '10', name: 'အောက်တိုဘာ', short: 'အောက်' },
  { value: '11', name: 'နိုဝင်ဘာ', short: 'နို' },
  { value: '12', name: 'ဒီဇင်ဘာ', short: 'ဒီ' },
];

export interface ThemeConfig {
  id: ThemeColor;
  name: string;
  myanmarName: string;
  primary: string; // hex
  primaryClass: string;
  gradient: string;
  badgeClass: string;
  ringClass: string;
}

export const THEME_CONFIGS: Record<ThemeColor, ThemeConfig> = {
  green: {
    id: 'green',
    name: 'Green',
    myanmarName: 'အစိမ်းရောင်',
    primary: '#10b981',
    primaryClass: 'bg-emerald-600 hover:bg-emerald-700 text-white',
    gradient: 'from-emerald-600 to-teal-700',
    badgeClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300',
    ringClass: 'ring-emerald-500 focus:ring-emerald-500',
  },
  blue: {
    id: 'blue',
    name: 'Blue',
    myanmarName: 'အပြာရောင်',
    primary: '#2563eb',
    primaryClass: 'bg-blue-600 hover:bg-blue-700 text-white',
    gradient: 'from-blue-600 to-indigo-700',
    badgeClass: 'bg-blue-100 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300',
    ringClass: 'ring-blue-500 focus:ring-blue-500',
  },
  purple: {
    id: 'purple',
    name: 'Purple',
    myanmarName: 'ခရမ်းရောင်',
    primary: '#8b5cf6',
    primaryClass: 'bg-purple-600 hover:bg-purple-700 text-white',
    gradient: 'from-purple-600 to-violet-800',
    badgeClass: 'bg-purple-100 text-purple-800 dark:bg-purple-950/70 dark:text-purple-300',
    ringClass: 'ring-purple-500 focus:ring-purple-500',
  },
  orange: {
    id: 'orange',
    name: 'Orange',
    myanmarName: 'လိမ္မော်ရောင်',
    primary: '#f97316',
    primaryClass: 'bg-orange-600 hover:bg-orange-700 text-white',
    gradient: 'from-orange-600 to-amber-700',
    badgeClass: 'bg-orange-100 text-orange-800 dark:bg-orange-950/70 dark:text-orange-300',
    ringClass: 'ring-orange-500 focus:ring-orange-500',
  },
};
