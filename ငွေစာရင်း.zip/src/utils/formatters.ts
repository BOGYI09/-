import { MYANMAR_MONTHS } from './constants';
import { NumberFormatType, Language } from '../types';

export const MYANMAR_DIGITS = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];

export const ENGLISH_MONTHS: Record<string, string> = {
  '01': 'January',
  '02': 'February',
  '03': 'March',
  '04': 'April',
  '05': 'May',
  '06': 'June',
  '07': 'July',
  '08': 'August',
  '09': 'September',
  '10': 'October',
  '11': 'November',
  '12': 'December',
};

export const toMyanmarDigits = (input: string | number): string => {
  return String(input).replace(/[0-9]/g, (digit) => MYANMAR_DIGITS[parseInt(digit, 10)]);
};

export const formatAmount = (
  amount: number,
  numberFormat: NumberFormatType = 'western',
  withCurrency: boolean = true,
  language: Language = 'my'
): string => {
  const safeAmount = isNaN(amount) ? 0 : Math.round(amount);
  const formattedWithCommas = new Intl.NumberFormat('en-US').format(safeAmount);

  const displayDigits =
    numberFormat === 'myanmar'
      ? toMyanmarDigits(formattedWithCommas)
      : formattedWithCommas;

  if (!withCurrency) return displayDigits;
  const currency = language === 'en' ? 'Kyat' : 'ကျပ်';
  return `${displayDigits} ${currency}`;
};

export const getMonthName = (monthCode: string, language: Language = 'my'): string => {
  if (language === 'en') {
    return ENGLISH_MONTHS[monthCode] || monthCode;
  }
  const found = MYANMAR_MONTHS.find((m) => m.value === monthCode);
  return found ? found.name : monthCode;
};

export const formatMonthKey = (
  monthKey: string, // YYYY-MM
  numberFormat: NumberFormatType = 'western',
  language: Language = 'my'
): string => {
  if (!monthKey || !monthKey.includes('-')) return monthKey;
  const [year, month] = monthKey.split('-');
  const monthName = getMonthName(month, language);

  if (language === 'en') {
    return `${monthName} ${year}`;
  }

  const displayYear = numberFormat === 'myanmar' ? toMyanmarDigits(year) : year;
  return `${displayYear} ခုနှစ်၊ ${monthName}လ`;
};

export const formatShortMonthKey = (
  monthKey: string,
  numberFormat: NumberFormatType = 'western',
  language: Language = 'my'
): string => {
  if (!monthKey || !monthKey.includes('-')) return monthKey;
  const [year, month] = monthKey.split('-');
  const monthName = getMonthName(month, language);

  if (language === 'en') {
    return `${monthName} ${year}`;
  }

  const displayYear = numberFormat === 'myanmar' ? toMyanmarDigits(year) : year;
  return `${monthName} ${displayYear}`;
};

export const formatDateDisplay = (
  dateStr: string, // YYYY-MM-DD
  numberFormat: NumberFormatType = 'western',
  language: Language = 'my'
): string => {
  if (!dateStr) return '';
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const yesterday = new Date();
  yesterday.setDate(now.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  if (dateStr === todayStr) {
    return language === 'en' ? 'Today' : 'ယနေ့';
  }
  if (dateStr === yesterdayStr) {
    return language === 'en' ? 'Yesterday' : 'မနေ့က';
  }

  const [year, month, day] = dateStr.split('-');
  const monthName = getMonthName(month, language);

  if (language === 'en') {
    return `${monthName.substring(0, 3)} ${parseInt(day, 10)}, ${year}`;
  }

  const displayDay = numberFormat === 'myanmar' ? toMyanmarDigits(parseInt(day, 10)) : parseInt(day, 10);
  const displayYear = numberFormat === 'myanmar' ? toMyanmarDigits(year) : year;

  return `${displayYear} ${monthName} ${displayDay} ရက်`;
};

// Backwards-compatibility alias
export const formatDateBurmese = (dateStr: string, numberFormat: NumberFormatType = 'western') =>
  formatDateDisplay(dateStr, numberFormat, 'my');

export const getCurrentMonthKey = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};

export const getTodayDateString = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};
