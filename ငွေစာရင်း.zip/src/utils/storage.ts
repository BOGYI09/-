import { Category, Expense, MonthlyIncome, ThemeColor, ThemeMode, NumberFormatType, Language } from '../types';
import { DEFAULT_CATEGORIES } from './constants';
import { getCurrentMonthKey, getTodayDateString } from './formatters';

const STORAGE_KEYS = {
  EXPENSES: 'ngwe_expenses_v2',
  INCOMES: 'ngwe_incomes_v2',
  CATEGORIES: 'ngwe_categories_v2',
  THEME_COLOR: 'ngwe_theme_color_v2',
  THEME_MODE: 'ngwe_theme_mode_v2',
  NUMBER_FORMAT: 'ngwe_number_format_v2',
  LANGUAGE: 'ngwe_language_v2',
};

const getSeedExpenses = (): Expense[] => {
  const today = getTodayDateString();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  const twoDaysAgo = new Date();
  twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
  const twoDaysAgoStr = twoDaysAgo.toISOString().split('T')[0];

  return [
    {
      id: 'seed-exp-1',
      title: 'ဆန်တစ်အိတ် ဝယ်ယူခြင်း',
      amount: 95000,
      categoryId: 'rice',
      date: today,
      note: 'ရွှေဘိုပေါ်ဆန်းမွှေး ဆန်တစ်အိတ်',
      createdAt: Date.now() - 1000 * 60 * 60 * 2,
    },
    {
      id: 'seed-exp-2',
      title: 'ဆီ ၁ ပိဿာနှင့် ဆားကြက်သွန်',
      amount: 28000,
      categoryId: 'groceries',
      date: today,
      note: 'အိမ်သုံး ဆီဆား ကြက်သွန်',
      createdAt: Date.now() - 1000 * 60 * 60 * 4,
    },
    {
      id: 'seed-exp-3',
      title: 'နေ့လယ်စာ စားသောက်ခြင်း',
      amount: 12000,
      categoryId: 'food',
      date: today,
      note: 'ထမင်းနှင့် ဟင်းပွဲများ',
      createdAt: Date.now() - 1000 * 60 * 60 * 5,
    },
    {
      id: 'seed-exp-4',
      title: 'သူငယ်ချင်းများနှင့် ဘီယာသောက်ခြင်း',
      amount: 24000,
      categoryId: 'beer',
      date: yesterdayStr,
      note: 'ညနေခင်း ဘီယာသောက်',
      createdAt: Date.now() - 1000 * 60 * 60 * 24,
    },
    {
      id: 'seed-exp-5',
      title: 'အိမ်သုံး အဖျားပျောက်ဆေးနှင့် ဗီတာမင်',
      amount: 15000,
      categoryId: 'medicine',
      date: yesterdayStr,
      note: 'ဆေးဝါးဝယ်ယူခြင်း',
      createdAt: Date.now() - 1000 * 60 * 60 * 28,
    },
    {
      id: 'seed-exp-6',
      title: 'ရုံးသွား ပြန် ကားခ Taxi',
      amount: 10000,
      categoryId: 'travel',
      date: twoDaysAgoStr,
      note: 'ခရီးစရိတ်',
      createdAt: Date.now() - 1000 * 60 * 60 * 50,
    },
  ];
};

export const getStoredExpenses = (): Expense[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    if (!raw) {
      const seed = getSeedExpenses();
      localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(seed));
      return seed;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse expenses from localStorage', err);
    return getSeedExpenses();
  }
};

export const saveStoredExpenses = (expenses: Expense[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
  } catch (err) {
    console.error('Failed to save expenses to localStorage', err);
  }
};

export const getStoredIncomes = (): MonthlyIncome[] => {
  try {
    const currentMonth = getCurrentMonthKey();
    const raw = localStorage.getItem(STORAGE_KEYS.INCOMES);
    if (!raw) {
      // Seed with 1,000,000 Kyat default for current month
      const initial: MonthlyIncome[] = [
        {
          monthKey: currentMonth,
          amount: 1000000,
          notes: 'လစဉ် အခြေခံ ဝင်ငွေ (လစာ)',
          updatedAt: Date.now(),
        },
      ];
      localStorage.setItem(STORAGE_KEYS.INCOMES, JSON.stringify(initial));
      return initial;
    }
    const parsed: MonthlyIncome[] = JSON.parse(raw);
    // ensure current month has an entry if none exists
    const hasCurrent = parsed.some((item) => item.monthKey === currentMonth);
    if (!hasCurrent) {
      parsed.push({
        monthKey: currentMonth,
        amount: 1000000,
        notes: 'လစဉ် အခြေခံ ဝင်ငွေ',
        updatedAt: Date.now(),
      });
      localStorage.setItem(STORAGE_KEYS.INCOMES, JSON.stringify(parsed));
    }
    return parsed;
  } catch (err) {
    console.error('Failed to load incomes', err);
    return [{
      monthKey: getCurrentMonthKey(),
      amount: 1000000,
      notes: 'လစဉ် အခြေခံ ဝင်ငွေ',
      updatedAt: Date.now(),
    }];
  }
};

export const saveStoredIncomes = (incomes: MonthlyIncome[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.INCOMES, JSON.stringify(incomes));
  } catch (err) {
    console.error('Failed to save incomes', err);
  }
};

export const getStoredCategories = (): Category[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
      return DEFAULT_CATEGORIES;
    }
    const parsed: Category[] = JSON.parse(raw);
    // Ensure all default categories exist in case an older version was stored
    const existingIds = new Set(parsed.map((c) => c.id));
    let updated = [...parsed];
    for (const def of DEFAULT_CATEGORIES) {
      if (!existingIds.has(def.id)) {
        updated.push(def);
      }
    }
    return updated;
  } catch (err) {
    console.error('Failed to load categories', err);
    return DEFAULT_CATEGORIES;
  }
};

export const saveStoredCategories = (categories: Category[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (err) {
    console.error('Failed to save categories', err);
  }
};

export const getStoredThemeColor = (): ThemeColor => {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.THEME_COLOR) as ThemeColor;
    if (val && ['green', 'blue', 'purple', 'orange'].includes(val)) {
      return val;
    }
  } catch (err) {
    console.error(err);
  }
  return 'green'; // Default is Green as requested
};

export const saveStoredThemeColor = (color: ThemeColor): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME_COLOR, color);
  } catch (err) {
    console.error(err);
  }
};

export const getStoredThemeMode = (): ThemeMode => {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.THEME_MODE) as ThemeMode;
    if (val && ['light', 'dark', 'system'].includes(val)) {
      return val;
    }
  } catch (err) {
    console.error(err);
  }
  return 'light';
};

export const saveStoredThemeMode = (mode: ThemeMode): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME_MODE, mode);
  } catch (err) {
    console.error(err);
  }
};

export const getStoredNumberFormat = (): NumberFormatType => {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.NUMBER_FORMAT) as NumberFormatType;
    if (val && ['western', 'myanmar'].includes(val)) {
      return val;
    }
  } catch (err) {
    console.error(err);
  }
  return 'western';
};

export const saveStoredNumberFormat = (format: NumberFormatType): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.NUMBER_FORMAT, format);
  } catch (err) {
    console.error(err);
  }
};

export const getStoredLanguage = (): Language => {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language;
    if (val === 'en' || val === 'my') {
      return val;
    }
  } catch (err) {
    console.error(err);
  }
  return 'my'; // Default Burmese as requested
};

export const saveStoredLanguage = (lang: Language): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  } catch (err) {
    console.error(err);
  }
};
