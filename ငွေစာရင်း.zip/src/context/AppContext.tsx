import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Category,
  Expense,
  MonthlyIncome,
  ThemeColor,
  ThemeMode,
  NumberFormatType,
  CategorySummary,
  Language,
} from '../types';
import {
  getStoredExpenses,
  saveStoredExpenses,
  getStoredIncomes,
  saveStoredIncomes,
  getStoredCategories,
  saveStoredCategories,
  getStoredThemeColor,
  saveStoredThemeColor,
  getStoredThemeMode,
  saveStoredThemeMode,
  getStoredNumberFormat,
  saveStoredNumberFormat,
  getStoredLanguage,
  saveStoredLanguage,
} from '../utils/storage';
import { getCurrentMonthKey } from '../utils/formatters';
import { THEME_CONFIGS } from '../utils/constants';
import { TRANSLATIONS, TranslationKey, DEFAULT_CATEGORY_EN_MAP } from '../utils/translations';

interface MonthStats {
  monthKey: string;
  totalIncome: number;
  totalExpenses: number;
  remainingBalance: number;
  expenses: Expense[];
  categorySummaries: CategorySummary[];
}

interface AppContextType {
  expenses: Expense[];
  incomes: MonthlyIncome[];
  categories: Category[];
  currentMonth: string;
  setCurrentMonth: (monthKey: string) => void;
  selectedCategoryFilter: string | null;
  setSelectedCategoryFilter: (id: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  themeColor: ThemeColor;
  setThemeColor: (color: ThemeColor) => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  numberFormat: NumberFormatType;
  setNumberFormat: (format: NumberFormatType) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  getCategoryName: (category: Category | { id: string; name: string }) => string;
  
  // Actions
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => Expense;
  updateExpense: (id: string, updated: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  setMonthIncome: (monthKey: string, amount: number, notes?: string) => void;
  addCategory: (category: Omit<Category, 'id'>) => Category;
  deleteCategory: (id: string) => void;
  
  // Computed for currentMonth
  totalIncome: number;
  totalExpenses: number;
  remainingBalance: number;
  currentMonthExpenses: Expense[];
  filteredExpenses: Expense[];
  categorySummaries: CategorySummary[];
  
  // General helper
  getMonthStats: (monthKey: string) => MonthStats;
  allAvailableMonths: string[];
  
  // Backup / Reset
  resetDataToDefault: () => void;
  exportDataJSON: () => string;
  importDataJSON: (jsonStr: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [expenses, setExpenses] = useState<Expense[]>(getStoredExpenses);
  const [incomes, setIncomes] = useState<MonthlyIncome[]>(getStoredIncomes);
  const [categories, setCategories] = useState<Category[]>(getStoredCategories);
  const [currentMonth, setCurrentMonth] = useState<string>(getCurrentMonthKey);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [themeColor, setThemeColorState] = useState<ThemeColor>(getStoredThemeColor);
  const [themeMode, setThemeModeState] = useState<ThemeMode>(getStoredThemeMode);
  const [numberFormat, setNumberFormatState] = useState<NumberFormatType>(getStoredNumberFormat);
  const [language, setLanguageState] = useState<Language>(getStoredLanguage);

  // Sync state to localStorage
  useEffect(() => {
    saveStoredExpenses(expenses);
  }, [expenses]);

  useEffect(() => {
    saveStoredIncomes(incomes);
  }, [incomes]);

  useEffect(() => {
    saveStoredCategories(categories);
  }, [categories]);

  // Handle language sync and html lang attribute
  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    saveStoredLanguage(lang);
  };

  const t = (key: TranslationKey): string => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS.my[key] || key;
  };

  const getCategoryName = (category: Category | { id: string; name: string }): string => {
    if (language === 'en') {
      return DEFAULT_CATEGORY_EN_MAP[category.id] || category.name;
    }
    return category.name;
  };

  // Handle Dark mode class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (themeMode === 'dark') {
      root.classList.add('dark');
    } else if (themeMode === 'light') {
      root.classList.remove('dark');
    } else {
      // system
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [themeMode]);

  // Update theme color meta tag
  useEffect(() => {
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', THEME_CONFIGS[themeColor]?.primary || '#10b981');
    }
  }, [themeColor]);

  const setThemeColor = (color: ThemeColor) => {
    setThemeColorState(color);
    saveStoredThemeColor(color);
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    saveStoredThemeMode(mode);
  };

  const setNumberFormat = (format: NumberFormatType) => {
    setNumberFormatState(format);
    saveStoredNumberFormat(format);
  };

  const addExpense = (newExpData: Omit<Expense, 'id' | 'createdAt'>): Expense => {
    const newExpense: Expense = {
      ...newExpData,
      id: 'exp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      createdAt: Date.now(),
    };
    setExpenses((prev) => [newExpense, ...prev]);
    return newExpense;
  };

  const updateExpense = (id: string, updated: Partial<Expense>) => {
    setExpenses((prev) =>
      prev.map((exp) => (exp.id === id ? { ...exp, ...updated } : exp))
    );
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((exp) => exp.id !== id));
  };

  const setMonthIncome = (monthKey: string, amount: number, notes?: string) => {
    setIncomes((prev) => {
      const idx = prev.findIndex((item) => item.monthKey === monthKey);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = {
          ...copy[idx],
          amount: Math.max(0, amount),
          notes: notes ?? copy[idx].notes,
          updatedAt: Date.now(),
        };
        return copy;
      } else {
        return [
          ...prev,
          {
            monthKey,
            amount: Math.max(0, amount),
            notes: notes || 'လစဉ် အခြေခံ ဝင်ငွေ',
            updatedAt: Date.now(),
          },
        ];
      }
    });
  };

  const addCategory = (catData: Omit<Category, 'id'>): Category => {
    const newCategory: Category = {
      ...catData,
      id: 'custom-cat-' + Date.now(),
      isCustom: true,
    };
    setCategories((prev) => [...prev, newCategory]);
    return newCategory;
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
    // If deleted category was selected in filter, clear it
    if (selectedCategoryFilter === id) {
      setSelectedCategoryFilter(null);
    }
  };

  // Helper to compute stats for any month key
  const getMonthStats = useMemo(() => {
    return (monthKey: string): MonthStats => {
      const monthExpenses = expenses.filter((e) => e.date.startsWith(monthKey));
      
      const incomeEntry = incomes.find((inc) => inc.monthKey === monthKey);
      // If none set, fallback to default 1,000,000 or nearest
      const totalIncome = incomeEntry ? incomeEntry.amount : (monthKey === getCurrentMonthKey() ? 1000000 : 0);
      
      const totalExpenses = monthExpenses.reduce((sum, item) => sum + (item.amount || 0), 0);
      const remainingBalance = totalIncome - totalExpenses;

      // Group by category
      const catMap = new Map<string, { total: number; count: number }>();
      monthExpenses.forEach((exp) => {
        const current = catMap.get(exp.categoryId) || { total: 0, count: 0 };
        catMap.set(exp.categoryId, {
          total: current.total + exp.amount,
          count: current.count + 1,
        });
      });

      const summaries: CategorySummary[] = [];
      catMap.forEach((val, catId) => {
        const cat = categories.find((c) => c.id === catId) || {
          id: catId,
          name: 'အခြား',
          icon: 'MoreHorizontal',
          color: '#64748b',
          bgColor: '#f1f5f9',
        };
        summaries.push({
          category: cat,
          totalAmount: val.total,
          percentage: totalExpenses > 0 ? (val.total / totalExpenses) * 100 : 0,
          count: val.count,
        });
      });

      // Sort by total amount descending
      summaries.sort((a, b) => b.totalAmount - a.totalAmount);

      return {
        monthKey,
        totalIncome,
        totalExpenses,
        remainingBalance,
        expenses: monthExpenses.sort((a, b) => {
          if (b.date === a.date) return b.createdAt - a.createdAt;
          return b.date.localeCompare(a.date);
        }),
        categorySummaries: summaries,
      };
    };
  }, [expenses, incomes, categories]);

  // Current month stats
  const currentMonthStats = useMemo(() => {
    return getMonthStats(currentMonth);
  }, [getMonthStats, currentMonth]);

  // Filtered expenses based on search and category filter for home view
  const filteredExpenses = useMemo(() => {
    let list = currentMonthStats.expenses;
    if (selectedCategoryFilter) {
      list = list.filter((e) => e.categoryId === selectedCategoryFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((e) => {
        const titleMatch = e.title.toLowerCase().includes(q);
        const noteMatch = e.note ? e.note.toLowerCase().includes(q) : false;
        const cat = categories.find((c) => c.id === e.categoryId);
        const catMatch = cat ? cat.name.toLowerCase().includes(q) : false;
        return titleMatch || noteMatch || catMatch;
      });
    }
    return list;
  }, [currentMonthStats.expenses, selectedCategoryFilter, searchQuery, categories]);

  // Collect all unique available months from expenses & incomes
  const allAvailableMonths = useMemo(() => {
    const set = new Set<string>();
    set.add(getCurrentMonthKey());
    expenses.forEach((e) => {
      if (e.date && e.date.length >= 7) {
        set.add(e.date.substring(0, 7));
      }
    });
    incomes.forEach((i) => {
      if (i.monthKey) set.add(i.monthKey);
    });
    return Array.from(set).sort().reverse();
  }, [expenses, incomes]);

  const resetDataToDefault = () => {
    localStorage.clear();
    setExpenses(getStoredExpenses());
    setIncomes(getStoredIncomes());
    setCategories(getStoredCategories());
    setCurrentMonth(getCurrentMonthKey());
    setThemeColorState('green');
    setThemeModeState('light');
    setNumberFormatState('western');
    setLanguageState('my');
  };

  const exportDataJSON = (): string => {
    const data = {
      version: 2,
      exportDate: new Date().toISOString(),
      expenses,
      incomes,
      categories,
    };
    return JSON.stringify(data, null, 2);
  };

  const importDataJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (Array.isArray(parsed.expenses)) {
        setExpenses(parsed.expenses);
      }
      if (Array.isArray(parsed.incomes)) {
        setIncomes(parsed.incomes);
      }
      if (Array.isArray(parsed.categories)) {
        setCategories(parsed.categories);
      }
      return true;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        expenses,
        incomes,
        categories,
        currentMonth,
        setCurrentMonth,
        selectedCategoryFilter,
        setSelectedCategoryFilter,
        searchQuery,
        setSearchQuery,
        themeColor,
        setThemeColor,
        themeMode,
        setThemeMode,
        numberFormat,
        setNumberFormat,
        language,
        setLanguage,
        t,
        getCategoryName,
        addExpense,
        updateExpense,
        deleteExpense,
        setMonthIncome,
        addCategory,
        deleteCategory,
        totalIncome: currentMonthStats.totalIncome,
        totalExpenses: currentMonthStats.totalExpenses,
        remainingBalance: currentMonthStats.remainingBalance,
        currentMonthExpenses: currentMonthStats.expenses,
        filteredExpenses,
        categorySummaries: currentMonthStats.categorySummaries,
        getMonthStats,
        allAvailableMonths,
        resetDataToDefault,
        exportDataJSON,
        importDataJSON,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
